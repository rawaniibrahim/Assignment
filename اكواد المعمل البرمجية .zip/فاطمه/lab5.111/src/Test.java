import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in);
        CircularlyLinkedList<String>l= new CircularlyLinkedList<>();
        int choice;
        while (true)
        {
            System.out.println("1 add first 2 add last 3 rotate 4 remove first 5 size 6 is the list empty -1 exit");
            System.out.println("input your choice");
            choice=scan.nextInt();
            switch (choice)
            {
                case 1:
                    System.out.println("input an element:");
                    l.addFirst(scan.next());
                    System.out.println(l.first()+" was added successfully");
                    break;
                case 2:
                    System.out.println("input an element:");
                    l.addLast(scan.next());
                    System.out.println(l.last()+" was added successfully");
                    break;
                case 3 :
                    l.rotate();
                    System.out.println("list element was rotated");
                    break;
                case 4 :
                    System.out.println(l.removeFirst()+" was removed ");
                    break;
                case 5 :
                    System.out.println("list size is :"+l.size());
                    break;
                case 6:
                    System.out.println("is the list empty? "+l.isEmpty());
                    break;
                case -1:
                    System.out.println("Good Bye");
                    System.exit(0);
            }
            System.out.println("list Elements are: "+l.getAll());
        }
    }
}
