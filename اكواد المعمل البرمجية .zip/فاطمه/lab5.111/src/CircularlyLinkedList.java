public class CircularlyLinkedList <E>{
    private static class Node<E>
    {
        private E element;
        private Node<E>next;

        public Node(E element, Node<E> next) {
            this.element = element;
            this.next = next;
        }

        public E getElement() {
            return element;
        }

        public void setElement(E element) {
            this.element = element;
        }

        public Node<E> getNext() {
            return next;
        }

        public void setNext(Node<E> next) {
            this.next = next;
        }
    }
    private Node<E>tail= null;
    private int size=0;
    public CircularlyLinkedList() {}
    public int size(){
        return size;
    }
    public boolean isEmpty()
    {
        return size==0;
    }
public E first()
{
    if (isEmpty())return null;
    return tail.next.element;

}
    public E last()
    {
        if (isEmpty())return null;
        return tail.element;

    }
    public void rotate()
    {
        if (tail!=null)
            tail=tail.next;
    }
    public void addFirst(E e)
    {
        if (size==0)
        {
            tail= new Node<>(e,null);
            tail.setNext(tail);
        }
        else {
            Node<E>n= new Node<>(e,tail.next);
            tail.setNext(n);
        }
        size++;
    }
    public void  addLast(E e)
    {
        addFirst(e);
        tail=tail.next;
    }
public E removeFirst()
{
    if (isEmpty())return null;
    Node<E>x=tail.next;
    if (x==tail)
        tail=null;
    else
        tail.setNext(x.getNext());
    size--;
   return x.element;
}
public String getAll()
{
    if (isEmpty())return "";
    String all="";
    Node<E>x=tail.next;
    for (int i = 0; i < size; i++) {
        all=all+x.getElement()+"  ";
        x=x.next;
    }
    return all;
}
}

