public interface Tree<E>extends Iterable<E> {
    Position<E>root();
    Position<E>parent(Position<E>p);
    boolean isEmpty();
    boolean isInternal(Position<E>p);
    boolean isExternal(Position<E>p);
    boolean isRoot(Position<E>p);
    int size();
    Iterable<Position<E>>children(Position<E>p);
    int numChildren(Position<E>p);
    Iterable<Position<E>>positions(Position<E>p);


}
