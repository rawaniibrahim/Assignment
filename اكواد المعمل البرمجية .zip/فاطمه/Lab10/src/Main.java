public class Main {
    public static void main(String[] args) {
     LinkedBinaryTree<Character>t= new LinkedBinaryTree<>();
     t.addRoot('A');
     t.addLeft(t.root(),'B');
     t.addRight(t.root(),'C');
        System.out.println(t.root().getElement());
        System.out.println(t.left(t.root()).getElement());
        System.out.println(t.right(t.root()).getElement());


    }
}