import java.lang.reflect.Array;
import java.util.ArrayList;

public abstract class AbstractBinaryTree<E> extends AbstractTree<E>implements BinaryTree<E> {
    @Override
    public Position<E> sibling(Position<E> p) {
        Position<E>parent=parent(p);
        if (left(parent)==p)
            return right(parent);
        else return left(parent);

    }

    @Override
    public Iterable<Position<E>> children(Position<E> p) {
        ArrayList<Position<E>> all=new ArrayList<>();
        if (left(p)!=null)
           all.add(left(p));
        if (right(p)!=null)
            all.add(right(p));
       return all;
    }

    @Override
    public int numChildren(Position<E> p) {
        int sum=0;
        if (left(p)!=null)
            sum++;
        if (right(p)!=null)
            sum++;
        return sum;
    }
}
