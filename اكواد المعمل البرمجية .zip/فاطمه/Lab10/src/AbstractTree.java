public  abstract class AbstractTree<E> implements Tree<E> {
    @Override
    public boolean isEmpty() {
        return size()==0;
    }

    @Override
    public boolean isInternal(Position<E> p) {
        return numChildren(p)!=0;
    }

    @Override
    public boolean isExternal(Position<E> p) {
        return numChildren(p)==0;
    }

    @Override
    public boolean isRoot(Position<E> p) {
        return root()==p;
    }
}
