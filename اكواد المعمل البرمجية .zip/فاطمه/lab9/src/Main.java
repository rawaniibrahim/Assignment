import java.util.Iterator;

public class Main {
    public static void main(String[] args) {

        PositionalLinkedList<Integer>l= new PositionalLinkedList<>();
        Position<Integer>p=l.addFirst(1);
        Position<Integer>p2=l.addAfter(p,3);
        l.addBefore(p2,2);
//        Position<Integer>i= l.first();
//        while (i!=null)
//        {
//            System.out.println(i.getElement());
//            i=l.after(i);
//        }
//        Iterator<Position<Integer>>i=l.iterator();
//        while (i.hasNext())
//            System.out.println(i.next().getElement());
//        for (Position<Integer>x:l) {
//            System.out.println(x.getElement());
//        }

        Iterator<Integer>i=l.iterator();
        while (i.hasNext())
            System.out.println(i.next());

    }
}