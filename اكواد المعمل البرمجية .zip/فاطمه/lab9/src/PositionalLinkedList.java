import java.util.Iterator;

public class PositionalLinkedList <E>implements PositionalList<E>, Iterable<E>{
    private Node<E>header;
    public Node<E>trailer;
    private int size=0;

    public PositionalLinkedList()
    {
        header= new Node<>(null,null,null);
        trailer= new Node<>(null,header,null);
        header.next= trailer;
    }
    private Node<E>validate(Position<E>p)
    {
        if (!(p instanceof Node))
            throw new IllegalArgumentException(" invalid position");
        Node<E>n=(Node<E>) p;
        if (n.next==null)
            throw new IllegalArgumentException(" p is not exist anymore");
        return n;
    }
    private Position<E>position(Node<E>n)
    {
        if (n==header||n==trailer)
            return null;
        return n;
    }
    @Override
    public Position<E> first() {
        return position(header.next);
    }

    @Override
    public Position<E> last() {
        return position(trailer.prev);
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size==0;
    }

    @Override
    public Position<E> after(Position<E> p) {
        Node<E>n=validate(p);
        return position(n.next);
    }

    @Override
    public Position<E> before(Position<E> p) {
        Node<E>n=validate(p);
        return position(n.prev);
    }

    private Position<E> addBetween(E e,Node<E>p,Node<E>n)
    {
        Node<E>newst=new Node<>(e,p,n);
        p.next=newst;
        n.prev=newst;
        size++;
        return newst;
    }
    @Override
    public Position<E> addFirst(E e) {
        return addBetween(e,header,header.next);
    }

    @Override
    public Position<E> addLast(E e) {
        return addBetween(e,trailer.prev,trailer);
    }

    @Override
    public Position<E> addBefore(Position<E> p, E e) {
        Node<E>n=validate(p);
        return addBetween(e,n.prev,n);
    }

    @Override
    public Position<E> addAfter(Position<E> p, E e) {
        Node<E>n=validate(p);
        return addBetween(e,n,n.next);    }

    @Override
    public E set(Position<E> p, E e) {
        Node<E>n=validate(p);
        E temp=n.element;
        n.element=e;
        return temp;
    }

    @Override
    public E remove(Position<E> p) {
        Node<E>n= validate(p);
        Node<E>pre=n.prev;
        Node<E>nex=n.next;
        pre.next=nex;
        nex.prev=pre;
        n.prev=null;
        n.next=null;
        E temp= n.element;
        n.element=null;
        size--;
        return temp;
    }

    @Override
    public Iterator<E> iterator() {
        return new ElementIterator();
    }
    private class PositionalIterator implements Iterator<Position<E>>
    {
        Position<E>recent=null;
        Position<E>cursor=first();

        @Override
        public boolean hasNext() {
            return cursor!=null;
        }

        @Override
        public Position<E> next() {
            if (cursor==null)
                throw new IllegalStateException(" no elemnt left");
            recent=cursor;
            cursor=after(cursor);
            return recent;
        }
    }
    private class ElementIterator implements Iterator<E>
    {
       PositionalIterator pos= new PositionalIterator();

        @Override
        public boolean hasNext() {
            return pos.hasNext();
        }

        @Override
        public E next() {
         return   pos.next().getElement();
        }
    }

    private static class Node<E>implements Position<E>
    {
        E element;
        Node<E>prev;
        Node<E>next;

        public Node(E element, Node<E> prev, Node<E> next) {
            this.element = element;
            this.prev = prev;
            this.next = next;
        }

        public void setElement(E element) {
            this.element = element;
        }

        public Node<E> getPrev() {
            return prev;
        }

        public void setPrev(Node<E> prev) {
            this.prev = prev;
        }

        public Node<E> getNext() {
            return next;
        }

        public void setNext(Node<E> next) {
            this.next = next;
        }

        @Override
        public E getElement() {
            return element;
        }
    }

}
