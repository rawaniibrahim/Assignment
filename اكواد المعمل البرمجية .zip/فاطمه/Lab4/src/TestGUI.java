import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TestGUI {
    private JPanel mainPanel;
    private JTextField textField1;
    private JButton addFromFirstButton;
    private JButton addFromLastButton;
    private JButton removeFromFirstButton;
    private JLabel sizeLabel;
    private JLabel emptyLabel;
    private JLabel listElementLabel;
    SinglyLinkedList<String>l= new SinglyLinkedList<>();
public TestGUI() {
    emptyLabel.setText(l.isEmpty()+"");
    sizeLabel.setText(l.size()+"");
    addFromFirstButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (!textField1.getText().equals(""))
                l.addFirst(textField1.getText());
            listElementLabel.setText(l.getAll());
            emptyLabel.setText(l.isEmpty()+"");
            sizeLabel.setText(l.size()+"");
            textField1.setText("");
        }
    });
    addFromLastButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (!textField1.getText().equals(""))
                l.addLast(textField1.getText());
            listElementLabel.setText(l.getAll());
            emptyLabel.setText(l.isEmpty()+"");
            sizeLabel.setText(l.size()+"");
            textField1.setText("");
        }
    });
    removeFromFirstButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
           l.removeFirst();
            listElementLabel.setText(l.getAll());
            emptyLabel.setText(l.isEmpty()+"");
            sizeLabel.setText(l.size()+"");
            textField1.setText("");
        }
    });
}

    public static void main(String[] args) {
        JFrame frame = new JFrame("TestGUI");
        frame.setContentPane(new TestGUI().mainPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
