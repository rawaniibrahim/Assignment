import java.util.Scanner;

public class TestQueue {
    public static void main(String[] args) {
        LinkedQueue<String>l= new LinkedQueue<>();
        int choice;
        Scanner in= new Scanner(System.in);
        while(true)
        {
            System.out.println("1 enqueue 2 dequeue 3 first 4 size 5 is the stack empty -1 exit");
            System.out.println("input your choice:");
            choice=in.nextInt();
            switch (choice)
            {
                case 1:
                    System.out.println("input your element: ");
                    l.enqueue(in.next());
                    System.out.println(l.first()+" was added ");
                    break;
                case 2:

                    System.out.println(l.dequeue()+" was removed");
                    break;
                case 3:
                    System.out.println(l.first()+" is the top");
                    break;
                case 4:
                    System.out.println(l.size()+" is the stack size");
                    break;
                case 5:
                    System.out.println("is the stack empty? "+l.isEmpty());
                    break;
                case -1:
                    System.exit(0);

            }
            LinkedStack<String>alt=new LinkedStack<>();

            for (int i = 0; i < l.size(); i++) {
                System.out.println(l.first());
                l.enqueue(l.dequeue());
            }
        }


    }

}
