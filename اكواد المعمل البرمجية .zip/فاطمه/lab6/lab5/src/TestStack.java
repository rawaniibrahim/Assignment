import java.util.Scanner;

public class TestStack {
    public static void main(String[] args) {
       LinkedStack<String>l= new LinkedStack<>();
        int choice;
        Scanner in= new Scanner(System.in);
        while(true)
        {
            System.out.println("1 push 2 pop 3 top 4 size 5 is the stack empty -1 exit");
            System.out.println("input your choice:");
            choice=in.nextInt();
            switch (choice)
            {
                case 1:
                    System.out.println("input your element: ");
                    l.push(in.next());
                    System.out.println(l.top()+" was added ");
                    break;
                case 2:

                    System.out.println(l.pop()+" was removed");
                    break;
                case 3:
                    System.out.println(l.top()+" is the top");
                    break;
                case 4:
                    System.out.println(l.size()+" is the stack size");
                    break;
                case 5:
                    System.out.println("is the stack empty? "+l.isEmpty());
                    break;
                case -1:
                    System.exit(0);

            }
            LinkedStack<String>alt=new LinkedStack<>();

            while (!l.isEmpty()){
                System.out.println(l.top());
              alt.push(l.pop());
            }
            while (!alt.isEmpty()){

                l.push(alt.pop());
            }

        }


    }

}
