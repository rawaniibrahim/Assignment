import java.util.Scanner;


public class Qq4 {
     public static void main(String[] args) {
          int[] num2 = new int[5];
        try (Scanner myscanner = new Scanner(System.in)) {
            for (int i = 0; i < num2.length; i++) {
                num2[i] = myscanner.nextInt();
            }
            
            for (int i = 0; i < num2.length; i++) {
                System.out.println(num2[i]);
            }
        }

    }
    
}

