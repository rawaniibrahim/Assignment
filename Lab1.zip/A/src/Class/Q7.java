package Class;

class Student {
    String name;
    int age;

    Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Name: " + name + ", Age: " + age;
    }
}

public class Q7 {
    public static void main(String[] args) {
        Student[] students = new Student[3];
        students[0] = new Student("Ali", 20);
        students[1] = new Student("Sara", 22);
        students[2] = new Student("Omar", 21);

        for (Student student : students) {
            System.out.println(student);
        }
    }
}