
package Class;

public class Q5 {
   
    public static void main(String[] args) {
          int[] numbers = {1, 2, 3, 4, 5};
        printArray(numbers);
    }

    public static void printArray(int[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i]);
}
}
}
 
}
