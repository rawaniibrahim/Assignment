package Class;

import java.util.Scanner;

public class Q6 {
     public static void Med204() {
        System.out.println("Enter the number");
     try (Scanner Am = new Scanner(System.in)) {
         int[] x = new int[4];
         
         for (int i = 0; i < x.length; i++) {
             x[i] = Am.nextInt();
         }
         
         for (int i = 0; i < x.length; i++) {
             System.out.println(x[i]);
         }
     }
    }

    public static void main(String[] args) {
        Med204();
}
}