
package HomeWork;

    
 public class Q10{
    public static void main(String[] args) {
        System.out.println(isMultiple(10, 2));
        System.out.println(isMultiple(10, 3));
    }

    public static boolean isMultiple(long n, long m) {
        if (m == 0) {
            return false;
        }
        return n % m == 0;
    }
}