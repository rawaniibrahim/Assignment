/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HomeWork;

class CreditCard {
    private String cardNumber;
    private String cardHolder;
    private double balance;
    private double creditLimit;

    public CreditCard(String cardNumber, String cardHolder, double creditLimit) {
        this.cardNumber = cardNumber;
        this.cardHolder = cardHolder;
        this.creditLimit = creditLimit;
        this.balance = 0;
    }

    public void makePurchase(double amount) {
        if (balance + amount <= creditLimit) {
            balance += amount;
        } else {
            System.out.println("Purchase exceeds credit limit.");
        }
    }

    public void makePayment(double amount) {
        if (amount > 0) {
            balance -= amount;
        }
    }

    public double getBalance() {
        return balance;
    }

    public double getCreditLimit() {
        return creditLimit;
    }

    public void updateCreditLimit(double newLimit) {
        creditLimit = newLimit;
    }
}

public class Q19 {
    public static void main(String[] args) {
        CreditCard card = new CreditCard("1234-5678-9876-5432", "John Doe", 5000);
        card.makePayment(-100);
        System.out.println("Balance after invalid payment: " + card.getBalance());
    }
}
