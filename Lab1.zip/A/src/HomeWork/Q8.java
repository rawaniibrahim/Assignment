
package HomeWork;

/**
 *
 * @author MOON
 */
    import java.util.Scanner;

public class Q8 {
    public static void main(String[] args) {
        inputAllBaseTypes();
    }

    public static void inputAllBaseTypes() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter a byte value: ");
            byte byteValue = scanner.nextByte();
            
            System.out.print("Enter a short value: ");
            short shortValue = scanner.nextShort();
            
            System.out.print("Enter an int value: ");
            int intValue = scanner.nextInt();
            
            System.out.print("Enter a long value: ");
            long longValue = scanner.nextLong();
            
            System.out.print("Enter a float value: ");
            float floatValue = scanner.nextFloat();
            
            System.out.print("Enter a double value: ");
            double doubleValue = scanner.nextDouble();
            
            System.out.print("Enter a char value: ");
            char charValue = scanner.next().charAt(0);
            
            System.out.print("Enter a boolean value: ");
            boolean booleanValue = scanner.nextBoolean();
            
            System.out.println("Byte: " + byteValue);
            System.out.println("Short: " + shortValue);
            System.out.println("Int: " + intValue);
            System.out.println("Long: " + longValue);
            System.out.println("Float: " + floatValue);
            System.out.println("Double: " + doubleValue);
            System.out.println("Char: " + charValue);
            System.out.println("Boolean: " + booleanValue);
        }
    }
}
}
