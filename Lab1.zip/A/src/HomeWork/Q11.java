
package HomeWork;

    public class Q11 {
    public static void main(String[] args) {
        System.out.println(isEven(4));
        System.out.println(isEven(5));
    }

    public static boolean isEven(int j) {
        return (j & 1) == 0;
    }
}