
package HomeWork;

class CreditCard {
    private String cardNumber;
    private String cardHolder;
    private double balance;
    private double creditLimit;

    public CreditCard(String cardNumber, String cardHolder, double creditLimit) {
        this.cardNumber = cardNumber;
        this.cardHolder = cardHolder;
        this.creditLimit = creditLimit;
        this.balance = 0;
    }

    public void makePurchase(double amount) {
        if (balance + amount <= creditLimit) {
            balance += amount;
        } else {
            System.out.println("Purchase exceeds credit limit for " + cardHolder);
        }
    }

    public double getBalance() {
        return balance;
    }

    public double getCreditLimit() {
        return creditLimit;
    }
}

public class Q20 {
    public static void main(String[] args) {
        CreditCard card1 = new CreditCard("1234-5678-9876-5432", "John Doe", 500);
        CreditCard card2 = new CreditCard("2345-6789-8765-4321", "Jane Smith", 1000);
        CreditCard card3 = new CreditCard("3456-7890-7654-3210", "Alice Johnson", 1500);

        double[] charges = {200, 300, 900}; // This will cause card1 to exceed its limit

        for (int i = 0; i < charges.length; i++) {
            if (i == 0) {
                card1.makePurchase(charges[i]);
            } else if (i == 1) {
                card2.makePurchase(charges[i]);
            } else {
                card3.makePurchase(charges[i]);
            }
        }
    }
}