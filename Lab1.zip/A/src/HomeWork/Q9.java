
package HomeWork;

    
    class GameEntry {
    int score;

    GameEntry(int score) {
        this.score = score;
    }
}

public class Q9 {
    public static void main(String[] args) {
        GameEntry[] A = new GameEntry[10];
        for (int i = 0; i < A.length; i++) {
            A[i] = new GameEntry(i * 100); 
        }

        GameEntry[] B = A.clone(); 

        A[4].score = 550; 

        System.out.println("Score in B[4]: " + B[4].score);
    }
}

