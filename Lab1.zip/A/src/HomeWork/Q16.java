/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HomeWork;

/**
 *
 * @author MOON
 */
public class Q16 {
    public static void main(String[] args) {
        System.out.println(removePunctuation("Let's try, Mike!"));
        System.out.println(removePunctuation("Hello, World."));
    }

    public static String removePunctuation(String str) {
        StringBuilder result = new StringBuilder();
        for (char c : str.toCharArray()) {
            if (!isPunctuation(c)) {
                result.append(c);
            }
        }
        return result.toString().replaceAll("\\s+", " ").trim();
    }

    private static boolean isPunctuation(char c) {
        return ",.!?;:'\"()-".indexOf(c) != -1;
    }
}