/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HomeWork;

/**
 *
 * @author MOON
 */
public class Q13 {
    public static void main(String[] args) {
        System.out.println(sumOddPositiveIntegers(10));
        System.out.println(sumOddPositiveIntegers(15));
    }

    public static int sumOddPositiveIntegers(int n) {
        int sum = 0;
        for (int i = 1; i <= n; i += 2) {
            sum += i;
        }
        return sum;
    }
}