
package HomeWork;

public class Q12 {

    public static void main(String[] args) {
        System.out.println(sumPositiveIntegers(5));
        System.out.println(sumPositiveIntegers(10));
    }

    public static int sumPositiveIntegers(int n) {
        int sum = 0;
        for (int i = 1; i <= n; i++) {
            sum += i;
        }
        return sum;
    }
}