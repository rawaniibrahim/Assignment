/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HomeWork;

import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author MOON
 */
public class CreditCardNGTest {
    
    public CreditCardNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of makePurchase method, of class CreditCard.
     */
    @Test
    public void testMakePurchase() {
        System.out.println("makePurchase");
        double amount = 0.0;
        CreditCard instance = null;
        instance.makePurchase(amount);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of makePayment method, of class CreditCard.
     */
    @Test
    public void testMakePayment() {
        System.out.println("makePayment");
        double amount = 0.0;
        CreditCard instance = null;
        instance.makePayment(amount);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getBalance method, of class CreditCard.
     */
    @Test
    public void testGetBalance() {
        System.out.println("getBalance");
        CreditCard instance = null;
        double expResult = 0.0;
        double result = instance.getBalance();
        assertEquals(result, expResult, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCreditLimit method, of class CreditCard.
     */
    @Test
    public void testGetCreditLimit() {
        System.out.println("getCreditLimit");
        CreditCard instance = null;
        double expResult = 0.0;
        double result = instance.getCreditLimit();
        assertEquals(result, expResult, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updateCreditLimit method, of class CreditCard.
     */
    @Test
    public void testUpdateCreditLimit() {
        System.out.println("updateCreditLimit");
        double newLimit = 0.0;
        CreditCard instance = null;
        instance.updateCreditLimit(newLimit);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
