/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HomeWork;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author MOON
 */
public class CreditCardTest {
    
    public CreditCardTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of makePurchase method, of class CreditCard.
     */
    @Test
    public void testMakePurchase() {
        System.out.println("makePurchase");
        double amount = 0.0;
        CreditCard instance = null;
        instance.makePurchase(amount);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of makePayment method, of class CreditCard.
     */
    @Test
    public void testMakePayment() {
        System.out.println("makePayment");
        double amount = 0.0;
        CreditCard instance = null;
        instance.makePayment(amount);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getBalance method, of class CreditCard.
     */
    @Test
    public void testGetBalance() {
        System.out.println("getBalance");
        CreditCard instance = null;
        double expResult = 0.0;
        double result = instance.getBalance();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCreditLimit method, of class CreditCard.
     */
    @Test
    public void testGetCreditLimit() {
        System.out.println("getCreditLimit");
        CreditCard instance = null;
        double expResult = 0.0;
        double result = instance.getCreditLimit();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updateCreditLimit method, of class CreditCard.
     */
    @Test
    public void testUpdateCreditLimit() {
        System.out.println("updateCreditLimit");
        double newLimit = 0.0;
        CreditCard instance = null;
        instance.updateCreditLimit(newLimit);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
